import icon from '../../assets/icons/icon.png';
import search from '../../assets/icons/search.png';
import factory from '../../assets/icons/factory.png';
import support from '../../assets/icons/support.png';
import store from '../../assets/icons/store.png';
import group from '../../assets/icons/group.png';
import consulting from '../../assets/icons/consulting.png';
import shipping from '../../assets/icons/shipping.png';
import assembly from '../../assets/icons/assembly.png';
import customize from '../../assets/icons/customize.png';
import price from '../../assets/icons/price.png';
import star from '../../assets/icons/star.png';
import plus from '../../assets/icons/plus.png';
import menu from '../../assets/icons/menu.png';
import close from '../../assets/icons/close.png';
import arrow from '../../assets/icons/arrow.png';
import whatsapp from '../../assets/icons/whatsapp.png';
import instagram from '../../assets/icons/instagram.png';
import youtube from '../../assets/icons/youtube.png';
import linkedin from '../../assets/icons/linkedin.png';
import tiktok from '../../assets/icons/tiktok.png';

export type IconName =
  | 'search'
  | 'factory'
  | 'support'
  | 'store'
  | 'group'
  | 'consulting'
  | 'shipping'
  | 'assembly'
  | 'customize'
  | 'price'
  | 'star'
  | 'plus'
  | 'menu'
  | 'close'
  | 'arrow'
  | 'whatsapp'
  | 'instagram'
  | 'youtube'
  | 'linkedin'
  | 'tiktok';

type IconProps = {
  name: IconName;
  className?: string;
  alt?: string;
};

const iconMap: Record<IconName, string> = {
  search: search,
  factory: factory,
  support: support,
  store: store,
  group: group,
  consulting: consulting,
  shipping: shipping,
  assembly: assembly,
  customize: customize,
  price: price,
  star: star,
  plus: plus,
  menu: menu,
  close: close,
  arrow: arrow,
  whatsapp: whatsapp,
  instagram: instagram,
  youtube: youtube,
  linkedin: linkedin,
  tiktok: tiktok,
};

export function Icon({
  name,
  className = 'size-5',
  alt = '',
}: IconProps) {
  return (
    <span
      role={alt ? 'img' : undefined}
      aria-label={alt || undefined}
      aria-hidden={alt ? undefined : true}
      className={className}
      style={{
        maskImage: `url(${iconMap[name]})`,
        WebkitMaskImage: `url(${iconMap[name]})`,
        maskSize: 'contain',
        WebkitMaskSize: 'contain',
        maskRepeat: 'no-repeat',
        WebkitMaskRepeat: 'no-repeat',
        maskPosition: 'center',
        WebkitMaskPosition: 'center',
        backgroundColor: 'currentColor',
      }}
      data-icon={name}
    />
  );
}