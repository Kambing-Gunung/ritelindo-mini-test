import aeonLogo from '../assets/images/trust/clients/aeon-logo.png';
import alfamartLogo from '../assets/images/trust/clients/alfamart-logo.png';
import bohopannaLogo from '../assets/images/trust/clients/bohopanna-logo.png';
import familymartLogo from '../assets/images/trust/clients/familymart-logo.png';
import indomaretLogo from '../assets/images/trust/clients/indomaret-logo.png';
import k3martLogo from '../assets/images/trust/clients/k3mart-logo.jpg';
import mayoraLogo from '../assets/images/trust/clients/mayora-logo.png';
import legendLogo from '../assets/images/trust/clients/pusatoleholehlegenda-logo.png';
import rbGrosirLogo from '../assets/images/trust/clients/rbgrosir-logo.png';
import wingsLogo from '../assets/images/trust/clients/wings-logo.png';

export type ClientBrand = {
  id: string;
  name: string;
  logo: string;
};

export type Testimonial = {
  rating: number;
  quote: string;
  name: string;
  role: string;
  location: string;
};

export const clientBrands: ClientBrand[] = [
  { id: 'aeon', name: 'AEON Supermarket', logo: aeonLogo },
  { id: 'alfamart', name: 'Alfamart', logo: alfamartLogo },
  { id: 'bohopanna', name: 'Bohopanna', logo: bohopannaLogo },
  { id: 'family-mart', name: 'Family Mart', logo: familymartLogo },
  { id: 'indomaret', name: 'Indomaret', logo: indomaretLogo },
  { id: 'k3-mart', name: 'K3 Mart', logo: k3martLogo },
  { id: 'mayora', name: 'Mayora', logo: mayoraLogo },
  { id: 'legend', name: 'Pusat Oleh-Oleh Legenda', logo: legendLogo },
  { id: 'rb-grosir', name: 'RB Grosir', logo: rbGrosirLogo },
  { id: 'wings', name: 'Wings Group', logo: wingsLogo },
];

export const featuredTestimonial: Testimonial[] = [
  {
    rating: 5,
    quote:
      'Prosesnya sangat mudah dan hasilnya memuaskan. Tim Ritelindo sangat profesional dari awal konsultasi hingga perakitan.',
    name: 'Bu Putri',
    role: 'Owner Toko Putri Salju',
    location: 'Kab. Malang, Jawa Timur',
  },
  {
    rating: 5,
    quote:
      'Gak nyangka toko saya bisa jadi secakep ini. Pemasangannya cepat dan pelayanannya juga ramah. Sukses untuk Ritelindo.',
    name: 'Mas Ari',
    role: 'Owner Toko Duta Wijaya',
    location: 'Kab. Bojonegro, Jawa Timur',
  },
  {
    rating: 5,
    quote:
      'Semuanya free pengiriman sama pemasangan, sangat luar biasa layanan nya baik puolll , pokoknya gak akan nyesel beli disini.',
    name: 'Kak Grahito',
    role: 'Owner Supermarket Argensta Jaya',
    location: 'Kab. Pasuruan, Jawa Timur',
  },
  {
    rating: 5,
    quote:
      'Rekomen banget pokoknya di Ritelindo. Dikasih layout 3D sama bebas pilih desain. Seneng banget pokonyaa',
    name: 'Bu Airin',
    role: 'Owner Toko Bangunan Sumber Makmur',
    location: 'Kab. Probolinggo, Jawa Timur',
  },
];
